<?php 

header("location: https://vk.com/video_ext.php?oid=760598098&id=456248141&hash=348b62083632e381");
?>
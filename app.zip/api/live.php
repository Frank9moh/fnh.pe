<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>صفحة الخلفية الصوتية</title>
</head>
<body>
    <button onclick="document.getElementById('background-audio').play()">تشغيل الصوت</button>
    <audio id="background-audio" loop>
        <source src="https://n0b.radiojar.com/8s5u5tpdtwzuv?rj-ttl=5&rj-tok=AAABkUKJczkAIwjaHMcM2ssZ1w" type="audio/mpeg">
        صوت متصفحك لا يدعم تشغيل الصوت
    </audio>
</body>
</html>
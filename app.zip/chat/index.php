<?php
header("location: https://olive-sunknave-fairy.toystack.dev/");
?>